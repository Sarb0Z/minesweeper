#include <iostream>
using namespace std;
#include "Game.h"
int main() {
	Game start;
	start.startGame();

	return 0;


}