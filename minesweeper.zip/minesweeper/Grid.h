#pragma once
#include "Tile.h"
class Grid
{
private:
    Tile **board;
    
public:
    Grid();
    Grid(Tile** &x);
    void set_Val();
    void initTiles();
    void uncoverTiles(int x, int y);
    void boundaryFill8(int x, int y);
    void floodFill(int x, int y);
    ~Grid() {
        for (int i = 0; i < 5; i++)
            delete[]board[i];
    }
};

