#pragma once
#include <SFML/Graphics.hpp>
class initGraphic 
{
private:
	sf::Texture* texture;
public:
	initGraphic();
	sf::Texture& getImg(int val);
	sf::Texture& getBomb();
	sf::Texture& getDefault();
	virtual void assignImages() = 0;
	virtual const sf::Sprite& getSprite() const = 0;
	virtual void updateTile() = 0;
	
};

