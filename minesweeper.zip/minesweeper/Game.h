#pragma once
#include "Grid.h"
class Game :
    public Grid
{
private:
    bool won;
    bool lost;
public:
    Game();
    void startGame();
    void endGame(Tile**& board);  
};

