#pragma once
#include "initGraphic.h"
class Tile: public initGraphic
{
private:
	int xpos;
	int ypos;
	bool filled = 0;
	int val = 0;
	sf::Sprite sprite;
	bool clicked = 0;
public:
	Tile();
	void fillTile();
	void setPos(int x, int y);
	bool isFilled();
	void setVal(int v);
	int getVal();
	void assignImages() override;
	const sf::Sprite& getSprite() const;
	void updateTile() override;
	bool is_clicked();
	void click();
};

