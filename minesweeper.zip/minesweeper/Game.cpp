#include "Game.h"
#include <SFML/Graphics.hpp>
Game::Game() {
	won = 0;
	lost = 0;
}
void Game::endGame(Tile**&board) {
	int count = 0;
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 5; j++) {
			if (board[i][j].is_clicked()) {
				if (board[i][j].isFilled()) {
					lost = 1;
				}
				else
					count++;
			}
			
		}
	}
	if (count == 20 && !lost) {
		won = 1;
	}
}

void Game::startGame() {
	sf::RenderWindow window(sf::VideoMode(500, 500), "MINESWEEPER");
	Tile** x;
	Grid game(x);
	
	game.initTiles();
	game.set_Val();
	sf::Event e;
	sf::Font font;
	sf::Text text;
	font.loadFromFile("Debrosee.ttf");
	text.setFont(font);
	text.setCharacterSize(50);
	text.setFillColor(sf::Color::Black);
	text.setPosition(150.f, 150.f);
	int clickedx;
	int clickedy;

	while (window.isOpen()) {

		while (window.pollEvent(e))
		{
			if (e.type == e.Closed) {
				window.close();
			}
			if (e.type == sf::Event::MouseButtonPressed)
			{
				clickedx = sf::Mouse::getPosition(window).x / 100;
				clickedy = sf::Mouse::getPosition(window).y / 100;
				if (clickedx < 5 && clickedy < 5) {
					x[clickedx][clickedy].click();
					//game.boundaryFill8(clickedx, clickedy);
					//game.boundaryFill8(clickedx,clickedy);
					game.uncoverTiles(clickedx,clickedy);
				}

			}

			if (!(won || lost)) {

				for (int i = 0; i < 5; i++) {
					for (int j = 0; j < 5; j++) {
						x[i][j].assignImages();
						x[i][j].updateTile();

						window.draw(x[i][j].getSprite());
					}
				}
				endGame(x);

			}
			if (lost) {
				text.setString("YOU LOST");
				window.draw(text);

			}
			if (won) {
				text.setString("YOU WON");
				window.draw(text);
			}
			window.display();
			window.clear(sf::Color(255, 165, 0));

		}
	}
}

